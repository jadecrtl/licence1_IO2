USE ProjetRJ;

INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('admin1', 'admin1@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'admin');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('admin2', 'admin2@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'admin');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('influe1', 'influe1@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'public');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('influe2', 'influe2@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'public');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('influe3', 'influe3@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'public');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('jade1', 'jade1@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'prive');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('jade2', 'jade2@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'prive');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('jade3', 'jade3@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'prive');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('rayana1', 'rayana1@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'prive');
INSERT INTO t_utilisateur (pseudonyme, adresse_mail, mot_de_passe, pouvoir) VALUES ('rayana2', 'rayana2@gmail.com', '$2y$10$vMNZVmC1NBQ1B3dpC25ODO8cCyv4TogplqfdkyUs/WABa6VYi4YWu', 'prive');

