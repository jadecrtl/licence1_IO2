USE ProjetRJ;


CALL ps_creer_commentaire('jade1', INT,'coucou jaime ta photo');
CALL ps_creer_commentaire('admin', INT,'coucou ');
CALL ps_creer_commentaire('jade1', INT,'ce commentaire est bien');
