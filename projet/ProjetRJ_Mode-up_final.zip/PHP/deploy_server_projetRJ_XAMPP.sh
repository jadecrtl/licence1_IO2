sudo cp -Rf * /opt/lampp/htdocs/mode-up/
