sudo cp -r * /Applications/MAMP/htdocs/mode-up/


