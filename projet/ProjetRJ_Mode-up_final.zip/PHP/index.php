<?php
    header('location: accueil.php');
    exit();
?>