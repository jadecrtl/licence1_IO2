<form action="accueil_recherche_ami.php" method="POST" class="recherche">
    <input type="text" name="critere_recherche" />
    <input type="submit" name="rechercher" value="Rechercher" />
</form>